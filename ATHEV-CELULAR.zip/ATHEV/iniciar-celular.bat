@echo off
call "%~dp0iniciar.bat" --host 0.0.0.0 --port 8000
