@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 server.py %*
  goto fim
)
where python >nul 2>nul
if not errorlevel 1 (
  python server.py %*
  goto fim
)
set "ATHEV_PY=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%ATHEV_PY%" (
  "%ATHEV_PY%" server.py %*
  goto fim
)
echo Python nao encontrado. Instale Python 3.10 ou mais recente e tente novamente.
echo https://www.python.org/downloads/
:fim
pause
