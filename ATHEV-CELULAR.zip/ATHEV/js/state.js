export const S={user:null,csrf:'',data:null,route:'home',auth:'login',filter:'Todos',search:'',evolutionTab:'geral',period:90,metric:'weight',calendar:new Date(),calendarMode:'month',selectedDate:'',adminSection:'dashboard',students:[],staff:null,student:null,templates:[],messages:[],editor:null,guide:null,busy:false};
export async function api(path,method='GET',data){
  const response=await fetch('/api'+path,{method,credentials:'same-origin',headers:method==='GET'?{}:{'Content-Type':'application/json','X-CSRF-Token':S.csrf},body:method==='GET'?undefined:JSON.stringify(data??{})});
  let result;try{result=await response.json();}catch{throw new Error('Inicie o servidor com iniciar.bat e abra http://localhost:8000.');}
  if(!response.ok){const error=new Error(result.error||'Não foi possível concluir a ação.');error.status=response.status;throw error;}
  return result;
}
